# U Moda — New Collection 2027

This package contains the product list extracted from `New collection 2027 U Moda.pdf`.

## Contents
- `products.json` — 44 product entries with product code, price in EGP, available sizes, description, source page, and image path.
- `images/` — one product-row image for each entry.

## Data notes
- Prices and sizes are transcribed from the supplied PDF.
- Repeated product codes are kept as separate entries because they appear as separate rows/models in the source.
- Product IDs are unique (`u-moda-2027-001`, etc.) and should be used as website keys instead of product codes.
- Descriptions are retained as written in the PDF; some entries use Arabic labels.

## Website integration
Upload this folder/package to the repository, then update the website's product catalogue to read `products.json` and resolve each `image` path relative to this package.
The exact integration file depends on the website framework and current repository structure. Do not delete the old catalogue until the new catalogue has been checked on the live preview.
